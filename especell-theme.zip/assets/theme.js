/**
 * Especell theme interactions.
 *
 * Every effect here degrades gracefully: if IntersectionObserver is missing,
 * or the visitor asks for reduced motion, content stays fully visible and
 * readable — motion is an enhancement, never a requirement.
 */
(function () {
  'use strict';

  var reduceMotion =
    window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  var supportsObserver = 'IntersectionObserver' in window;

  /* ------------------------------------------------------------------
   * Reveal on scroll, with stagger for grouped children
   * ---------------------------------------------------------------- */
  function initReveal() {
    var targets = document.querySelectorAll('[data-animate]');
    if (!targets.length) return;

    if (reduceMotion || !supportsObserver) {
      targets.forEach(function (el) {
        el.classList.add('is-visible');
      });
      return;
    }

    // Stagger siblings that share a parent so grids cascade in.
    var seen = new Map();
    targets.forEach(function (el) {
      var parent = el.parentElement;
      var index = seen.get(parent) || 0;
      seen.set(parent, index + 1);
      if (index > 0 && index < 8) {
        el.style.setProperty('--reveal-delay', index * 80 + 'ms');
      }
    });

    var observer = new IntersectionObserver(
      function (entries) {
        entries.forEach(function (entry) {
          if (!entry.isIntersecting) return;
          entry.target.classList.add('is-visible');
          observer.unobserve(entry.target);
        });
      },
      { threshold: 0.12, rootMargin: '0px 0px -40px 0px' }
    );

    targets.forEach(function (el) {
      observer.observe(el);
    });
  }

  /* ------------------------------------------------------------------
   * Count-up numbers when they scroll into view
   * ---------------------------------------------------------------- */
  function initCounters() {
    var counters = document.querySelectorAll('[data-counter]');
    if (!counters.length) return;

    function paint(el, value) {
      el.textContent = String(value);
    }

    if (reduceMotion || !supportsObserver) {
      counters.forEach(function (el) {
        paint(el, parseInt(el.dataset.counter, 10) || 0);
      });
      return;
    }

    function run(el) {
      var target = parseInt(el.dataset.counter, 10);
      if (isNaN(target)) return;

      var duration = 1400;
      var start = null;

      function step(timestamp) {
        if (start === null) start = timestamp;
        var progress = Math.min((timestamp - start) / duration, 1);
        // easeOutExpo keeps the last digits from crawling
        var eased = progress === 1 ? 1 : 1 - Math.pow(2, -10 * progress);
        paint(el, Math.round(eased * target));
        if (progress < 1) window.requestAnimationFrame(step);
      }

      window.requestAnimationFrame(step);
    }

    var observer = new IntersectionObserver(
      function (entries) {
        entries.forEach(function (entry) {
          if (!entry.isIntersecting) return;
          run(entry.target);
          observer.unobserve(entry.target);
        });
      },
      { threshold: 0.5 }
    );

    counters.forEach(function (el) {
      paint(el, 0);
      observer.observe(el);
    });
  }

  /* ------------------------------------------------------------------
   * Parallax layers
   * ---------------------------------------------------------------- */
  function initParallax() {
    var layers = document.querySelectorAll('[data-parallax]');
    if (!layers.length || reduceMotion) return;

    var ticking = false;

    function update() {
      layers.forEach(function (el) {
        var rect = el.getBoundingClientRect();
        // Skip work for anything comfortably off-screen
        if (rect.bottom < -200 || rect.top > window.innerHeight + 200) return;
        var speed = parseFloat(el.dataset.parallaxSpeed || '0.12');
        var scale = el.dataset.parallaxScale || '1.08';
        el.style.transform =
          'translate3d(0,' + rect.top * speed + 'px, 0) scale(' + scale + ')';
      });
      ticking = false;
    }

    window.addEventListener(
      'scroll',
      function () {
        if (ticking) return;
        window.requestAnimationFrame(update);
        ticking = true;
      },
      { passive: true }
    );

    update();
  }

  /* ------------------------------------------------------------------
   * Subtle 3D tilt following the pointer
   * ---------------------------------------------------------------- */
  function initTilt() {
    var cards = document.querySelectorAll('[data-tilt]');
    if (!cards.length || reduceMotion) return;

    // Pointer tilt makes no sense on touch-only devices.
    if (!window.matchMedia('(hover: hover) and (pointer: fine)').matches) return;

    var MAX = 5; // degrees

    cards.forEach(function (card) {
      var frame = null;

      card.addEventListener('pointermove', function (event) {
        if (frame) return;
        frame = window.requestAnimationFrame(function () {
          var rect = card.getBoundingClientRect();
          var px = (event.clientX - rect.left) / rect.width - 0.5;
          var py = (event.clientY - rect.top) / rect.height - 0.5;
          card.style.transform =
            'perspective(900px) rotateX(' +
            (-py * MAX).toFixed(2) +
            'deg) rotateY(' +
            (px * MAX).toFixed(2) +
            'deg) translateY(-6px)';
          frame = null;
        });
      });

      card.addEventListener('pointerleave', function () {
        if (frame) {
          window.cancelAnimationFrame(frame);
          frame = null;
        }
        card.style.transform = '';
      });
    });
  }

  /* ------------------------------------------------------------------
   * Magnetic buttons — they lean toward the cursor
   * ---------------------------------------------------------------- */
  function initMagnetic() {
    var magnets = document.querySelectorAll('[data-magnetic]');
    if (!magnets.length || reduceMotion) return;
    if (!window.matchMedia('(hover: hover) and (pointer: fine)').matches) return;

    var STRENGTH = 0.22;

    magnets.forEach(function (el) {
      var frame = null;

      el.addEventListener('pointermove', function (event) {
        if (frame) return;
        frame = window.requestAnimationFrame(function () {
          var rect = el.getBoundingClientRect();
          var dx = (event.clientX - (rect.left + rect.width / 2)) * STRENGTH;
          var dy = (event.clientY - (rect.top + rect.height / 2)) * STRENGTH;
          el.style.setProperty('--magnet-x', dx.toFixed(1) + 'px');
          el.style.setProperty('--magnet-y', dy.toFixed(1) + 'px');
          frame = null;
        });
      });

      el.addEventListener('pointerleave', function () {
        if (frame) {
          window.cancelAnimationFrame(frame);
          frame = null;
        }
        el.style.setProperty('--magnet-x', '0px');
        el.style.setProperty('--magnet-y', '0px');
      });
    });
  }

  /* ------------------------------------------------------------------
   * Mobile navigation
   * ---------------------------------------------------------------- */
  function initMenu() {
    var toggle = document.querySelector('[data-menu-toggle]');
    var menu = document.querySelector('[data-mobile-menu]');
    if (!toggle || !menu) return;

    toggle.addEventListener('click', function () {
      var isOpen = menu.hasAttribute('data-open');
      if (isOpen) {
        menu.removeAttribute('data-open');
        toggle.setAttribute('aria-expanded', 'false');
      } else {
        menu.setAttribute('data-open', '');
        toggle.setAttribute('aria-expanded', 'true');
      }
    });

    // Close the menu after tapping a link.
    menu.addEventListener('click', function (event) {
      if (event.target.closest('a')) {
        menu.removeAttribute('data-open');
        toggle.setAttribute('aria-expanded', 'false');
      }
    });
  }

  /* ------------------------------------------------------------------
   * Header shadow once the page scrolls
   * ---------------------------------------------------------------- */
  function initHeaderState() {
    var header = document.querySelector('[data-site-header]');
    if (!header) return;

    var ticking = false;

    function update() {
      header.classList.toggle('is-scrolled', window.scrollY > 12);
      ticking = false;
    }

    window.addEventListener(
      'scroll',
      function () {
        if (ticking) return;
        window.requestAnimationFrame(update);
        ticking = true;
      },
      { passive: true }
    );

    update();
  }

  /* ------------------------------------------------------------------
   * FAQ: keep only one answer open at a time
   * ---------------------------------------------------------------- */
  function initAccordion() {
    var groups = document.querySelectorAll('[data-accordion]');
    groups.forEach(function (group) {
      var items = group.querySelectorAll('details');
      items.forEach(function (item) {
        item.addEventListener('toggle', function () {
          if (!item.open) return;
          items.forEach(function (other) {
            if (other !== item) other.open = false;
          });
        });
      });
    });
  }

  function init() {
    initReveal();
    initCounters();
    initParallax();
    initTilt();
    initMagnetic();
    initMenu();
    initHeaderState();
    initAccordion();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
